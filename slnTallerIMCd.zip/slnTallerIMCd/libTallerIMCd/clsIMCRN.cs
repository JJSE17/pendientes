﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libTallerIMCd
{
    public class clsIMC
    {
        #region "Attributes"
        private double dblImcRN;
        private string strError;
        private double dblheight;
        private double dblweight;
        #endregion

        #region "Builders"
        public clsIMC()
        {
            this.dblImcRN = 0;
            this.strError = "";
            this.dblheight = 0;
            this.dblweight = 0;
        }
        #endregion

        #region "Properties"
        public double weight { set => dblweight = value; }  
        public double height { set => dblheight = value; }
        public double IMCRN { get => dblImcRN; }
        public string Error { get => strError; }
     
        #endregion

        #region "Private Methods"
        private bool validateDataRN()
        {
            if (dblheight < 0)
            {
                strError = "La estatura debe ser mayor que cero";
                return false;
            }
            if (dblweight < 0)
            {
                strError = "El peso debe ser mayor que cero";
                return false;
            }
            return true;
        }
        #endregion
        
        #region "Public Mephods"
        public bool CalcularIMC()
        {
            try
            {
                if (!validateDataRN())
                {
                    return false;
                }

                dblImcRN = dblheight / (dblweight * dblweight);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            #endregion  
        }
    }
}
  

