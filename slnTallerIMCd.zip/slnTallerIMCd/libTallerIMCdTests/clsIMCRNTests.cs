﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using libTallerIMCd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libTallerIMCd.Tests
{
    [TestClass()]
    public class clsIMCRNTests
    {
        [TestMethod]
        public void CalcularIMC()
        {
            clsIMC imc = new clsIMC();
            imc.height = 1.78;
            imc.weight = 70;

            bool result = imc.CalcularIMC();

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CalcularIMCNegativoAltura()
        {
            var imcCalculator = new clsIMC();
            imcCalculator.weight = 70;
            imcCalculator.height = -1.7;

            var result = imcCalculator.CalcularIMC();

            Assert.IsFalse(result);
            Assert.AreEqual("La estatura debe ser mayor que cero", imcCalculator.Error);
        }

        [TestMethod]
        public void CalcularIMCNegativoPeso()
        {
            var imcCalculator = new clsIMC();
            imcCalculator.weight = -98;
            imcCalculator.height = 1.7;

            var result = imcCalculator.CalcularIMC();

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CalculateIMC()
        {
            clsIMC imc = new clsIMC();
            imc.height = -70;
            imc.weight = 1.70;

            bool result = imc.CalcularIMC();

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CalculaterIMC()
        {
            var imcCalculator = new clsIMC();
            imcCalculator.weight = 70;
            imcCalculator.height = 17;

            var result = imcCalculator.CalcularIMC();

            Assert.IsTrue(result);
        }
    }
}