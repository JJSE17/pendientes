﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using libTallerIMCd;

namespace prjTallerIMCd
{
    public partial class frmCalculadora : Form
    {
        #region "Attributes"
        private double dblImcRN;
        private double dblEstatura;
        private double dblPeso;
        #endregion
       
        #region
        public frmCalculadora()
        {
            InitializeComponent();
        }
        #endregion

        #region "Private Methods"
        private void Process()
        {
            try
            {
                if (!valid())
                {
                    return;     
                }
            
            
                clsIMC objCheck = new clsIMC();

                objCheck.weight = Convert.ToDouble(txtHeight.Text);
                objCheck.height = Convert.ToDouble(txtWeight.Text);
                if (!objCheck.CalcularIMC())
                {
                MessageBox.Show(objCheck.Error, "Calculadora IMC", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                objCheck = null;
                return;
                }
                this.txtResultado.Text = objCheck.IMCRN.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Calculadora IMC", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clean()
        {
            this.txtName.Text = "";
            this.txtHeight.Text = "";
            this.txtWeight.Text = "";
            this.txtResultado.Text = "";
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Clean();
        }
        private bool CapData()
        {
            try
            {
                if (!valid())
                {
                    return false;
                }
                this.dblEstatura = Convert.ToDouble(txtHeight.Text.Trim());
                this.dblPeso = Convert.ToDouble(txtWeight.Text.Trim());
                this.dblImcRN = Convert.ToDouble(txtResultado.Text.Trim());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Calculadora IMC", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            return true;

        }
        private bool valid()
        {
            if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("Debe ingresar su nombre", " Calculadora IMC", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtName.Focus();
            }
            if (txtHeight.Text.Trim() == "")
            {
                MessageBox.Show("Debe ingresar su Estatura", " Calculadora IMC", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtHeight.Focus();
            }
            if (txtWeight.Text.Trim() == "")
            {
                MessageBox.Show("Debe ingresar su Peso", " Calculadora IMC", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtWeight.Focus();
            }
            return true;

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Process();
        }

        #endregion

        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {
            txtHeight.Text = "";
            txtName.Text = "";
            txtWeight.Text = "";
            txtResultado.Text = "";
        }
    }

}
    
